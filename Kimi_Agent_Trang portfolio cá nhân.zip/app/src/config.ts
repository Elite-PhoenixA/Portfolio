// ============================================================
// Site Configuration
// ============================================================

export interface SiteConfig {
  language: string;
  brandName: string;
}

export const siteConfig: SiteConfig = {
  language: "vi",
  brandName: "MINH.TRAN",
};

// ============================================================
// Navigation
// ============================================================

export interface NavLink {
  label: string;
  href: string;
}

export interface NavigationConfig {
  links: NavLink[];
  ctaText: string;
}

export const navigationConfig: NavigationConfig = {
  links: [
    { label: "Giới thiệu", href: "#hero" },
    { label: "Kỹ năng", href: "#curriculum" },
    { label: "Dự án", href: "#alumni" },
    { label: "Liên hệ", href: "#footer" },
  ],
  ctaText: "Tải CV",
};

// ============================================================
// Hero
// ============================================================

export interface HeroConfig {
  title: string;
  subtitleLine1: string;
  subtitleLine2: string;
  ctaText: string;
  avatarImage: string;
  bannerImage: string;
}

export const heroConfig: HeroConfig = {
  title: "MINH TRẦN",
  subtitleLine1: "Kỹ sư phần mềm Full-stack — 6 năm kiến tạo sản phẩm số",
  subtitleLine2: "Hà Nội, Việt Nam · Sẵn sàng cho dự án freelance",
  ctaText: "Khám phá hồ sơ",
  avatarImage: "/images/avatar.png",
  bannerImage: "/images/banner.png",
};

// ============================================================
// Capabilities (Curriculum section)
// ============================================================

export interface CapabilityItem {
  title: string;
  slug: string;
  description: string;
  image: string;
}

export interface CapabilitiesConfig {
  sectionLabel: string;
  items: CapabilityItem[];
}

export const capabilitiesConfig: CapabilitiesConfig = {
  sectionLabel: "KỸ NĂNG CHUYÊN MÔN",
  items: [
    {
      title: "Phát triển Web",
      slug: "phat-trien-web",
      description:
        "Xây dựng giao diện web hiện đại với React, TypeScript và Tailwind CSS. Tập trung vào hiệu năng, khả năng truy cập và trải nghiệm người dùng mượt mà trên mọi thiết bị.",
      image: "/images/cap-frontend.png",
    },
    {
      title: "Hệ thống Backend",
      slug: "he-thong-backend",
      description:
        "Thiết kế API và kiến trúc hệ thống vững chắc với Node.js, PostgreSQL và Redis. Kinh nghiệm triển khai microservices, tối ưu truy vấn và mở rộng hệ thống chịu tải cao.",
      image: "/images/cap-backend.png",
    },
    {
      title: "Ứng dụng Mobile",
      slug: "ung-dung-mobile",
      description:
        "Phát triển ứng dụng di động đa nền tảng bằng React Native và Flutter. Tối ưu trải nghiệm cảm ứng, hiệu năng render và tích hợp sâu với tính năng native của thiết bị.",
      image: "/images/cap-mobile.jpg",
    },
    {
      title: "Thiết kế UI/UX",
      slug: "thiet-ke-ui-ux",
      description:
        "Thiết kế giao diện tinh gọn, nhất quán theo hệ thống design system. Thành thạo Figma, prototyping và nghiên cứu người dùng để đưa ra quyết định thiết kế dựa trên dữ liệu.",
      image: "/images/cap-design.jpg",
    },
  ],
};

// ============================================================
// Capability Detail (sub-pages)
// ============================================================

export interface CapabilityDetailData {
  title: string;
  subtitle: string;
  paragraphs: string[];
}

export interface CapabilityDetailConfig {
  sectionLabel: string;
  backLinkText: string;
  prevLabel: string;
  nextLabel: string;
  notFoundText: string;
  capabilities: Record<string, CapabilityDetailData>;
}

export const capabilityDetailConfig: CapabilityDetailConfig = {
  sectionLabel: "CHI TIẾT KỸ NĂNG",
  backLinkText: "← Quay lại trang chủ",
  prevLabel: "Kỹ năng trước",
  nextLabel: "Kỹ năng tiếp",
  notFoundText: "Không tìm thấy nội dung này.",
  capabilities: {
    "phat-trien-web": {
      title: "Phát triển Web",
      subtitle: "React · TypeScript · Hiệu năng tối ưu",
      paragraphs: [
        "Tôi bắt đầu hành trình lập trình web từ năm 2019 và đã trải qua hơn 30 dự án thực tế, từ landing page cho startup đến hệ thống quản trị phức tạp cho doanh nghiệp. Công nghệ cốt lõi tôi sử dụng hằng ngày là React, TypeScript, Vite và Tailwind CSS — bộ công cụ giúp tôi cân bằng giữa tốc độ phát triển và chất lượng mã nguồn.",
        "Điểm mạnh của tôi nằm ở khả năng tối ưu hiệu năng: giảm thời gian tải trang, phân tách bundle, memoization và virtual hoá danh sách lớn. Nhiều dự án tôi tham gia đã đạt điểm Lighthouse trên 90 và cải thiện tỷ lệ chuyển đổi rõ rệt cho khách hàng.",
        "Bên cạnh kỹ thuật, tôi đề cao khả năng truy cập (accessibility) và chuẩn semantic HTML. Một sản phẩm tốt là sản phẩm mà bất kỳ ai — kể cả người khuyết tật — đều có thể sử dụng trọn vẹn.",
      ],
    },
    "he-thong-backend": {
      title: "Hệ thống Backend",
      subtitle: "Node.js · PostgreSQL · Kiến trúc mở rộng",
      paragraphs: [
        "Tôi thiết kế và vận hành các hệ thống backend phục vụ hàng trăm nghìn người dùng, với trọng tâm là Node.js, PostgreSQL và hạ tầng Docker. Triết lý của tôi là bắt đầu đơn giản, đo lường mọi thứ, và chỉ mở rộng khi dữ liệu thực tế đòi hỏi.",
        "Kinh nghiệm của tôi bao gồm thiết kế RESTful API và GraphQL, xây dựng hàng đợi xử lý bất đồng bộ với Redis/BullMQ, caching đa tầng, cũng như phân mảnh cơ sở dữ liệu khi hệ thống tăng trưởng. Tôi cũng có kinh nghiệm thực chiến với CI/CD, giám sát và xử lý sự cố lúc nửa đêm.",
        "Tôi tin rằng một hệ thống backend tốt không chỉ chạy nhanh mà còn dễ bảo trì: mã nguồn rõ ràng, migration an toàn, log đầy đủ và tài liệu API luôn đồng bộ với thực tế.",
      ],
    },
    "ung-dung-mobile": {
      title: "Ứng dụng Mobile",
      subtitle: "React Native · Flutter · Trải nghiệm native",
      paragraphs: [
        "Tôi phát triển ứng dụng di động đa nền tảng với React Native và Flutter, giúp khách hàng ra mắt sản phẩm trên cả iOS và Android chỉ với một codebase. Các ứng dụng tôi từng xây dựng trải dài từ giao đồ ăn, ngân hàng số đến đặt lịch khám bệnh.",
        "Với mobile, tôi đặc biệt chú trọng cảm giác sử dụng: animation 60fps, thao tác cử chỉ tự nhiên, offline-first và thời lượng pin. Người dùng không quan tâm bạn dùng framework nào — họ chỉ nhớ ứng dụng có mượt hay không.",
        "Tôi cũng thành thạo quy trình đưa ứng dụng lên App Store và Google Play: ký số, review, phát hành theo giai đoạn và phân tích sự cố sau release bằng Crashlytics và Sentry.",
      ],
    },
    "thiet-ke-ui-ux": {
      title: "Thiết kế UI/UX",
      subtitle: "Figma · Design System · Nghiên cứu người dùng",
      paragraphs: [
        "Trước khi viết dòng code đầu tiên, tôi luôn bắt đầu bằng việc hiểu người dùng. Tôi thực hiện phỏng vấn, vẽ user journey và xây dựng prototype trong Figma để kiểm chứng giả định sớm nhất có thể — khi chi phí thay đổi còn rẻ.",
        "Tôi xây dựng và duy trì design system với design token, thư viện component và quy ước nhất quán giữa thiết kế và code. Điều này giúp đội ngũ phát triển nhanh hơn và sản phẩm giữ được sự thống nhất khi mở rộng.",
        "Phong cách thiết kế của tôi thiên về tối giản: loại bỏ mọi yếu tố không cần thiết, dùng typography và khoảng trắng để dẫn dắt ánh nhìn, và chỉ dùng màu sắc để nhấn mạnh hành động quan trọng.",
      ],
    },
  },
};

// ============================================================
// Architecture (CinematicVision section)
// ============================================================

export interface ArchitectureConfig {
  sectionLabel: string;
  videoPath: string;
  title: string;
  description: string;
}

export const architectureConfig: ArchitectureConfig = {
  sectionLabel: "",
  videoPath: "",
  title: "",
  description: "",
};

// ============================================================
// Research (AlumniArchives section)
// ============================================================

export interface ResearchProject {
  title: string;
  year: string;
  discipline: string;
  image: string;
}

export interface ResearchConfig {
  sectionLabel: string;
  projects: ResearchProject[];
}

export const researchConfig: ResearchConfig = {
  sectionLabel: "DỰ ÁN TIÊU BIỂU",
  projects: [
    { title: "Sàn thương mại điện tử", year: "2024", discipline: "E-commerce / Web", image: "/images/p1.jpg" },
    { title: "Dashboard phân tích dữ liệu", year: "2024", discipline: "Data Visualization", image: "/images/p2.jpg" },
    { title: "Ứng dụng giao đồ ăn", year: "2023", discipline: "Mobile App", image: "/images/p3.jpg" },
    { title: "Nền tảng học trực tuyến", year: "2023", discipline: "EdTech Platform", image: "/images/p4.jpg" },
    { title: "Hệ thống quản lý kho", year: "2022", discipline: "Enterprise SaaS", image: "/images/p5.jpg" },
    { title: "Ứng dụng ngân hàng số", year: "2022", discipline: "FinTech / Mobile", image: "/images/p6.jpg" },
    { title: "Website bất động sản", year: "2021", discipline: "Real Estate Web", image: "/images/p7.jpg" },
    { title: "Nền tảng đặt lịch khám", year: "2021", discipline: "HealthTech", image: "/images/p8.jpg" },
  ],
};

// ============================================================
// Footer
// ============================================================

export interface FooterLinkColumn {
  title: string;
  links: string[];
}

export interface FooterBottomLink {
  label: string;
  href: string;
}

export interface FooterConfig {
  heading: string;
  columns: FooterLinkColumn[];
  copyright: string;
  bottomLinks: FooterBottomLink[];
}

export const footerConfig: FooterConfig = {
  heading: "Hãy cùng hợp tác!",
  columns: [
    {
      title: "Liên hệ",
      links: ["hello@minhtran.dev", "+84 912 345 678", "Hà Nội, Việt Nam"],
    },
    {
      title: "Kết nối",
      links: ["GitHub", "LinkedIn", "Facebook", "X (Twitter)"],
    },
  ],
  copyright: "© 2026 Minh Trần. Mọi quyền được bảo lưu.",
  bottomLinks: [
    { label: "Chính sách bảo mật", href: "#" },
    { label: "Điều khoản sử dụng", href: "#" },
  ],
};
