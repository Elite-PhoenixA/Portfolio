import { useRef, useEffect, useState } from 'react';
import AmberCascades from './AmberCascades';
import LiquidGlassButton from '../components/LiquidGlassButton';
import { heroConfig } from '../config';

export default function Hero() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const [titleWidth, setTitleWidth] = useState<number>(0);

  useEffect(() => {
    const measure = () => {
      if (titleRef.current) setTitleWidth(titleRef.current.offsetWidth);
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  if (!heroConfig.title) {
    return null;
  }

  const avatarSize = 'clamp(110px, 14vw, 168px)';

  return (
    <section
      id="hero"
      className="relative w-full overflow-hidden"
      style={{ minHeight: '100vh' }}
    >
      <AmberCascades />
      <div
        className="relative z-10 flex flex-col justify-between pointer-events-none"
        style={{
          minHeight: '100vh',
          padding: '14vh 5vw 8vh',
        }}
      >
        <div>
          {(heroConfig.bannerImage || heroConfig.avatarImage) && (
            <div
              style={{
                position: 'relative',
                marginBottom: `calc(${avatarSize} / 2 + clamp(20px, 3vw, 40px))`,
              }}
            >
              {heroConfig.bannerImage && (
                <div
                  style={{
                    width: '100%',
                    height: 'clamp(170px, 26vh, 300px)',
                    borderRadius: '20px',
                    overflow: 'hidden',
                    border: '1px solid rgba(200, 170, 130, 0.25)',
                    boxShadow: '0 24px 60px rgba(0,0,0,0.55)',
                  }}
                >
                  <img
                    src={heroConfig.bannerImage}
                    alt="Banner"
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      display: 'block',
                    }}
                  />
                </div>
              )}
              {heroConfig.avatarImage && (
                <img
                  src={heroConfig.avatarImage}
                  alt="Avatar"
                  style={{
                    position: 'absolute',
                    left: 'clamp(16px, 4vw, 48px)',
                    bottom: `calc(-1 * ${avatarSize} / 2)`,
                    width: avatarSize,
                    height: avatarSize,
                    borderRadius: '50%',
                    objectFit: 'cover',
                    border: '4px solid rgba(200, 170, 130, 0.85)',
                    background: '#0a0a0a',
                    boxShadow: '0 12px 40px rgba(0,0,0,0.65)',
                  }}
                />
              )}
            </div>
          )}
          <h1
            ref={titleRef}
            className="text-white"
            style={{
              fontFamily: "'GeistMono', monospace",
              fontWeight: 400,
              fontSize: 'clamp(48px, 6vw, 96px)',
              lineHeight: 1.0,
              letterSpacing: '-3px',
              textShadow: '0 4px 24px rgba(0,0,0,0.8)',
              marginBottom: 'clamp(32px, 4vw, 56px)',
              width: 'fit-content',
            }}
          >
            {heroConfig.title}
          </h1>
          {heroConfig.subtitleLine1 && (
            <p
              style={{
                fontFamily: "'GeistMono', monospace",
                fontWeight: 200,
                fontSize: 'clamp(15px, 1.5vw, 22px)',
                lineHeight: 1.7,
                letterSpacing: '-0.3px',
                color: '#ffffff',
                margin: '0 0 12px 0',
                width: titleWidth || 'auto',
                maxWidth: '100%',
                textShadow: '0 2px 12px rgba(0,0,0,0.6)',
              }}
            >
              {heroConfig.subtitleLine1}
            </p>
          )}
          {heroConfig.subtitleLine2 && (
            <p
              style={{
                fontFamily: "'GeistMono', monospace",
                fontWeight: 200,
                fontSize: 'clamp(15px, 1.5vw, 22px)',
                lineHeight: 1.7,
                letterSpacing: '-0.3px',
                color: '#ffffff',
                margin: 0,
                width: titleWidth || 'auto',
                maxWidth: '100%',
                textShadow: '0 2px 12px rgba(0,0,0,0.6)',
              }}
            >
              {heroConfig.subtitleLine2}
            </p>
          )}
        </div>

        {heroConfig.ctaText && (
          <div style={{ display: 'flex', justifyContent: 'center' }} className="pointer-events-auto">
            <LiquidGlassButton
              onClick={() => {
                document.querySelector('#curriculum')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              {heroConfig.ctaText}
            </LiquidGlassButton>
          </div>
        )}
      </div>
    </section>
  );
}
